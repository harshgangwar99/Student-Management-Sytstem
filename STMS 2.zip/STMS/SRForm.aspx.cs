﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class SRForm : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Data STMS"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btninsert_Click(object sender, EventArgs e)
    {
       
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into Students values('" + txtstdid.Text + "','" + txtstdname.Text + "','" + txtclass.Text + "','" + txtaddress.Text + "')", con);
        cmd.ExecuteNonQuery();
        lbl.Text = "insert successfully!!!!!!!!............";
        txtstdid.Text = "";
        txtstdname.Text = "";
        txtclass.Text = "";
        txtaddress.Text = "";
        con.Close();

    }
   



    protected void btncancel_Click(object sender, EventArgs e)
    {
       // con.Open();
        
       // con.Close();

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update Students set Student_Name = '"+ txtstdname.Text +"',Student_Class = '"+ txtclass.Text + "' where Student_id = '" + txtstdid.Text +"'",con);
        cmd.ExecuteNonQuery();
        lbl.Text = "Update Successfully!!!!!!!......";
        con.Close();                                     
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("Delete from Students where Student_id = '" + txtstdid.Text + "'", con);
        cmd.ExecuteNonQuery();
        lbl.Text = "Delete Successfully!!!!!!!......";
        con.Close();
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        con.Open();
        string a = "select * from Students ";
        SqlCommand cmd = new SqlCommand(a, con);

        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txtstdid.Text = dr["Student_id"].ToString();
            txtstdname.Text = dr["Student_Name"].ToString();
            txtclass.Text = dr["Student_Class"].ToString();
            txtaddress.Text = dr["Student_Address"].ToString();
        }

    }
}