﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class LoginForm : System.Web.UI.Page
{
   SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Data STMS"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void login_btn(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from adlogin  where Username='" + txtusername.Text + "' and Passwrd='" + txtpaswrd.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Response.Redirect("STMSForm.aspx");

        }
        con.Close();

    }

    /*  try
       {


           con.Open();
           Response.Write("<SCRIPT> alert('connection') </SCRIPT>");
           string a = ("select * from RegistrationForm where Username='" + txtusername.Text + "' and Password='" + txtpaswrd.Text + "'");
           SqlCommand cmd = new SqlCommand(a, con);

           SqlDataReader dr = cmd.ExecuteReader();
           if (dr.Read())
           {
               dr.Close();
               Response.Redirect("SRForm.aspx");

           }
           else
           {

               lbl.Visible = true;
               lbl.Text = "Invalid Password";


           }
       }
       catch (Exception e1)
       {
           Response.Write("<SCRIPT> alert('connection not') </SCRIPT>");
       } */
}

  
    